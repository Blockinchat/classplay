import { BrowsingHistoryItem } from '../types';

const HISTORY_KEY = 'blockins_history';

export const saveToHistory = (item: BrowsingHistoryItem): void => {
  try {
    const history = getHistory();
    // Avoid duplicates, remove any existing entry with the same URL
    const filteredHistory = history.filter(historyItem => historyItem.url !== item.url);
    // Add new item at the beginning
    const newHistory = [item, ...filteredHistory].slice(0, 50); // Keep only last 50 items
    localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
  } catch (error) {
    console.error('Failed to save to history:', error);
  }
};

export const getHistory = (): BrowsingHistoryItem[] => {
  try {
    const historyJson = localStorage.getItem(HISTORY_KEY);
    return historyJson ? JSON.parse(historyJson) : [];
  } catch (error) {
    console.error('Failed to get history:', error);
    return [];
  }
};

export const clearHistory = (): void => {
  try {
    localStorage.removeItem(HISTORY_KEY);
  } catch (error) {
    console.error('Failed to clear history:', error);
  }
};