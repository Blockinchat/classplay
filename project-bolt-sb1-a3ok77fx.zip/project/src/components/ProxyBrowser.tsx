import React, { useState, useEffect, useRef } from 'react';
import { Search, RefreshCw, Home as HomeIcon, ArrowLeft, ArrowRight } from 'lucide-react';
import { saveToHistory } from '../utils/storage';

interface ProxyBrowserProps {
  initialUrl?: string;
}

const ProxyBrowser: React.FC<ProxyBrowserProps> = ({ initialUrl = 'https://duckduckgo.com/' }) => {
  const [url, setUrl] = useState(initialUrl);
  const [inputUrl, setInputUrl] = useState(initialUrl);
  const [isLoading, setIsLoading] = useState(false);
  const [title, setTitle] = useState('DuckDuckGo');
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [history, setHistory] = useState<string[]>([initialUrl]);
  const [historyIndex, setHistoryIndex] = useState(0);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    let processedUrl = inputUrl;
    
    // Check if the input is a search query or URL
    if (!inputUrl.includes('.') || inputUrl.includes(' ')) {
      // It's a search query, redirect to DuckDuckGo search
      const searchQuery = encodeURIComponent(inputUrl);
      processedUrl = `https://duckduckgo.com/?q=${searchQuery}`;
    } else if (!inputUrl.startsWith('http://') && !inputUrl.startsWith('https://')) {
      // Add https:// if missing
      processedUrl = `https://${inputUrl}`;
    }
    
    navigateTo(processedUrl);
  };

  const navigateTo = (targetUrl: string) => {
    setIsLoading(true);
    setUrl(targetUrl);
    setInputUrl(targetUrl);
    
    // Update browser history
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push(targetUrl);
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
    
    // Save to browsing history
    saveToHistory({
      url: targetUrl,
      title: title,
      timestamp: Date.now()
    });
  };

  const handleIframeLoad = () => {
    setIsLoading(false);
    try {
      // Try to get the title from the iframe
      if (iframeRef.current?.contentDocument?.title) {
        setTitle(iframeRef.current.contentDocument.title);
      }
    } catch (error) {
      // Cross-origin issues might prevent accessing the title
      console.error('Could not access iframe content:', error);
    }
  };

  const goBack = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setUrl(history[historyIndex - 1]);
      setInputUrl(history[historyIndex - 1]);
    }
  };

  const goForward = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setUrl(history[historyIndex + 1]);
      setInputUrl(history[historyIndex + 1]);
    }
  };

  const goHome = () => {
    navigateTo('https://duckduckgo.com/');
  };

  const refresh = () => {
    setIsLoading(true);
    if (iframeRef.current) {
      iframeRef.current.src = url;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-220px)] min-h-[500px] bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="bg-[#332248] text-white p-3 flex items-center">
        <div className="flex space-x-2 mr-3">
          <button 
            onClick={goBack} 
            disabled={historyIndex === 0}
            className={`p-1.5 rounded-full ${historyIndex === 0 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#443259]'}`}
            title="Go back"
          >
            <ArrowLeft size={18} />
          </button>
          
          <button 
            onClick={goForward} 
            disabled={historyIndex >= history.length - 1}
            className={`p-1.5 rounded-full ${historyIndex >= history.length - 1 ? 'opacity-50 cursor-not-allowed' : 'hover:bg-[#443259]'}`}
            title="Go forward"
          >
            <ArrowRight size={18} />
          </button>
          
          <button 
            onClick={refresh} 
            className="p-1.5 rounded-full hover:bg-[#443259]"
            title="Refresh"
          >
            <RefreshCw size={18} />
          </button>
          
          <button 
            onClick={goHome} 
            className="p-1.5 rounded-full hover:bg-[#443259]"
            title="Home"
          >
            <HomeIcon size={18} />
          </button>
        </div>
        
        <form onSubmit={handleSearch} className="flex-grow">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={16} className="text-gray-300" />
            </div>
            <input
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              className="block w-full pl-10 pr-3 py-2 rounded-full bg-[#443259] border border-[#554269] focus:outline-none focus:ring-2 focus:ring-purple-300 text-white"
              placeholder="Search or enter URL"
            />
          </div>
        </form>
      </div>
      
      <div className="relative flex-grow bg-gray-100">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-70 z-10">
            <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-[#332248]"></div>
          </div>
        )}
        
        <iframe
          ref={iframeRef}
          src={url}
          title="Proxy Browser"
          className="w-full h-full border-0"
          onLoad={handleIframeLoad}
          sandbox="allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts"
        />
      </div>
    </div>
  );
};

export default ProxyBrowser;