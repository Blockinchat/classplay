import React from 'react';
import { Globe } from 'lucide-react';
import { Link, Outlet, useLocation } from 'react-router-dom';

const Layout: React.FC = () => {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="bg-[#332248] text-white shadow-md">
        <div className="container mx-auto px-4 py-3">
          <div className="flex flex-col sm:flex-row justify-between items-center">
            <div className="flex items-center mb-3 sm:mb-0">
              <Globe className="mr-2 h-6 w-6" />
              <h1 className="text-xl font-bold">BLockins Web</h1>
            </div>
            
            <nav className="flex space-x-1 sm:space-x-2">
              <Link 
                to="/" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 
                  ${isActive('/') 
                    ? 'bg-white text-[#332248]' 
                    : 'text-gray-200 hover:bg-[#443259] hover:text-white'}`}
              >
                Home
              </Link>
              <Link 
                to="/proxy" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 
                  ${isActive('/proxy') 
                    ? 'bg-white text-[#332248]' 
                    : 'text-gray-200 hover:bg-[#443259] hover:text-white'}`}
              >
                Proxy
              </Link>
              <Link 
                to="/games" 
                className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 
                  ${isActive('/games') 
                    ? 'bg-white text-[#332248]' 
                    : 'text-gray-200 hover:bg-[#443259] hover:text-white'}`}
              >
                Games
              </Link>
            </nav>
          </div>
        </div>
      </header>
      
      <main className="flex-grow container mx-auto px-4 py-6">
        <Outlet />
      </main>
      
      <footer className="bg-[#332248] text-white py-4">
        <div className="container mx-auto px-4 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} BLockins Web. All rights reserved.</p>
          <p className="mt-1 text-gray-300 text-xs">
            This tool is for educational purposes only. Use responsibly.
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;