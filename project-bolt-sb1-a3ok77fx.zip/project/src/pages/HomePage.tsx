import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Globe, Gamepad2 } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-12 space-y-4">
        <h1 className="text-4xl font-bold text-[#332248]">Welcome to BLockins Web</h1>
        <p className="text-xl text-gray-600">Your gateway to unrestricted web browsing</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 flex flex-col items-center text-center">
          <Shield className="h-12 w-12 text-[#332248] mb-4" />
          <h2 className="text-xl font-semibold mb-2">Private Browsing</h2>
          <p className="text-gray-600 mb-4">Browse the web privately and securely using our proxy service powered by DuckDuckGo.</p>
          <Link 
            to="/proxy" 
            className="mt-auto inline-block px-4 py-2 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200"
          >
            Start Browsing
          </Link>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 flex flex-col items-center text-center">
          <Globe className="h-12 w-12 text-[#332248] mb-4" />
          <h2 className="text-xl font-semibold mb-2">Bypass Restrictions</h2>
          <p className="text-gray-600 mb-4">Access blocked content and websites through our secure proxy service.</p>
          <Link 
            to="/proxy" 
            className="mt-auto inline-block px-4 py-2 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200"
          >
            Unblock Sites
          </Link>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 flex flex-col items-center text-center">
          <Gamepad2 className="h-12 w-12 text-[#332248] mb-4" />
          <h2 className="text-xl font-semibold mb-2">Game Collection</h2>
          <p className="text-gray-600 mb-4">Enjoy our collection of games to pass the time while staying anonymous.</p>
          <Link 
            to="/games" 
            className="mt-auto inline-block px-4 py-2 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200"
          >
            Play Games
          </Link>
        </div>
      </div>
      
      <div className="bg-white p-8 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-[#332248] mb-4">How It Works</h2>
        <div className="space-y-6">
          <div className="flex items-start">
            <div className="flex-shrink-0 bg-[#332248] text-white rounded-full w-8 h-8 flex items-center justify-center mr-4">1</div>
            <div>
              <h3 className="font-semibold text-lg">Enter a URL or search query</h3>
              <p className="text-gray-600">Type the address of the website you want to visit or search for content.</p>
            </div>
          </div>
          
          <div className="flex items-start">
            <div className="flex-shrink-0 bg-[#332248] text-white rounded-full w-8 h-8 flex items-center justify-center mr-4">2</div>
            <div>
              <h3 className="font-semibold text-lg">Browse through our secure proxy</h3>
              <p className="text-gray-600">Our proxy service will load the website, bypassing restrictions.</p>
            </div>
          </div>
          
          <div className="flex items-start">
            <div className="flex-shrink-0 bg-[#332248] text-white rounded-full w-8 h-8 flex items-center justify-center mr-4">3</div>
            <div>
              <h3 className="font-semibold text-lg">Enjoy unrestricted access</h3>
              <p className="text-gray-600">Access content that may be blocked in your network or region.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <Link 
            to="/proxy" 
            className="px-6 py-3 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200 font-medium"
          >
            Start Browsing Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;