import React, { useState } from 'react';
import { GameType } from '../types';
import { Gamepad2 } from 'lucide-react';

const gamesData: GameType[] = [
  {
    id: '1',
    title: '2048',
    description: 'Join the numbers and get to the 2048 tile!',
    imageUrl: 'https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg',
    url: 'https://play2048.co/'
  },
  {
    id: '2',
    title: 'Flappy Bird',
    description: 'Navigate the bird through pipes without touching them.',
    imageUrl: 'https://images.pexels.com/photos/1126728/pexels-photo-1126728.jpeg',
    url: 'https://flappybird.io/'
  },
  {
    id: '3',
    title: 'Tetris',
    description: 'Classic tetris game. Arrange falling blocks to create complete rows.',
    imageUrl: 'https://images.pexels.com/photos/207924/pexels-photo-207924.jpeg',
    url: 'https://tetris.com/play-tetris'
  },
  {
    id: '4',
    title: 'Snake',
    description: 'Control a snake to eat food and grow longer without hitting walls or yourself.',
    imageUrl: 'https://images.pexels.com/photos/1111597/pexels-photo-1111597.jpeg',
    url: 'https://playsnake.org/'
  },
  {
    id: '5',
    title: 'Chess',
    description: 'Play the classic game of chess against the computer or other players.',
    imageUrl: 'https://images.pexels.com/photos/260024/pexels-photo-260024.jpeg',
    url: 'https://www.chess.com/play/computer'
  },
  {
    id: '6',
    title: 'Sudoku',
    description: 'Fill in the grid so that every row, column, and region contains the digits 1-9.',
    imageUrl: 'https://images.pexels.com/photos/6230975/pexels-photo-6230975.jpeg',
    url: 'https://sudoku.com/'
  }
];

const GamesPage: React.FC = () => {
  const [selectedGame, setSelectedGame] = useState<GameType | null>(null);
  
  const handleGameSelect = (game: GameType) => {
    setSelectedGame(game);
  };
  
  const handleBackToGames = () => {
    setSelectedGame(null);
  };

  if (selectedGame) {
    return (
      <div>
        <button 
          onClick={handleBackToGames}
          className="mb-4 px-4 py-2 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200 flex items-center"
        >
          ← Back to Games
        </button>
        
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="p-4 bg-[#332248] text-white">
            <h2 className="text-xl font-bold">{selectedGame.title}</h2>
          </div>
          
          <div className="h-[calc(100vh-300px)] min-h-[500px]">
            <iframe 
              src={selectedGame.url} 
              title={selectedGame.title}
              className="w-full h-full border-0"
              sandbox="allow-forms allow-modals allow-orientation-lock allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts"
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center mb-6">
        <Gamepad2 className="h-8 w-8 text-[#332248] mr-3" />
        <h1 className="text-2xl font-bold text-[#332248]">Games Collection</h1>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {gamesData.map(game => (
          <div 
            key={game.id} 
            className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
          >
            <img 
              src={game.imageUrl} 
              alt={game.title} 
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <h2 className="text-xl font-semibold text-[#332248] mb-2">{game.title}</h2>
              <p className="text-gray-600 mb-4">{game.description}</p>
              <button
                onClick={() => handleGameSelect(game)}
                className="w-full px-4 py-2 bg-[#332248] text-white rounded-md hover:bg-[#443259] transition-colors duration-200"
              >
                Play Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GamesPage;