import React, { useState } from 'react';
import ProxyBrowser from '../components/ProxyBrowser';
import { getHistory, clearHistory } from '../utils/storage';
import { Clock } from 'lucide-react';

const ProxyPage: React.FC = () => {
  const [showHistory, setShowHistory] = useState(false);
  const history = getHistory();
  
  const handleClearHistory = () => {
    clearHistory();
    setShowHistory(false);
    // Force re-render
    window.location.reload();
  };
  
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-[#332248]">Web Proxy</h1>
        
        <div className="relative">
          <button 
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center px-3 py-2 text-sm font-medium text-[#332248] border border-[#332248] rounded-md hover:bg-[#332248] hover:text-white transition-colors duration-200"
          >
            <Clock size={16} className="mr-2" />
            History
          </button>
          
          {showHistory && (
            <div className="absolute right-0 mt-2 w-72 bg-white rounded-md shadow-lg z-10 overflow-hidden">
              <div className="py-2 px-3 bg-[#332248] text-white flex justify-between items-center">
                <h3 className="font-medium">Browsing History</h3>
                <button 
                  onClick={handleClearHistory}
                  className="text-xs bg-red-500 px-2 py-1 rounded hover:bg-red-600 transition-colors duration-200"
                >
                  Clear
                </button>
              </div>
              
              <div className="max-h-60 overflow-y-auto">
                {history.length === 0 ? (
                  <p className="p-3 text-gray-500 text-sm text-center">No browsing history</p>
                ) : (
                  <ul>
                    {history.map((item, index) => (
                      <li key={index} className="border-b last:border-b-0">
                        <a 
                          href={item.url} 
                          className="block px-3 py-2 hover:bg-gray-100 truncate"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <div className="text-sm font-medium text-gray-800 truncate">
                            {item.title || item.url}
                          </div>
                          <div className="text-xs text-gray-500 truncate">{item.url}</div>
                          <div className="text-xs text-gray-400">{formatDate(item.timestamp)}</div>
                        </a>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="bg-white p-4 rounded-lg shadow-md mb-6">
        <p className="text-gray-600">
          This proxy allows you to browse the web anonymously and access blocked content.
          Enter a URL or search query in the browser below.
        </p>
      </div>
      
      <ProxyBrowser />
    </div>
  );
};

export default ProxyPage;