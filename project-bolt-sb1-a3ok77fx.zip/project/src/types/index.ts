export interface GameType {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  url: string;
}

export interface BrowsingHistoryItem {
  url: string;
  title: string;
  timestamp: number;
}